package com.example.dashboard.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import java.util.List;

@Data
@Component
@ConfigurationProperties(prefix = "apps")
public class AppConfig {
    private List<MonitoredApp> monitored;

    @Data
    public static class MonitoredApp {
        private String name;
        private String url;
        private String type;
        private String host;
        private int port;
    }
}
