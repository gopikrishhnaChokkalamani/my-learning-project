package com.example.dashboard.service;

import com.example.dashboard.config.AppConfig;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import redis.clients.jedis.Jedis;
import java.util.Map;

@Service
public class HealthCheckService {

    private final RestTemplate restTemplate = new RestTemplate();

    public String checkStatus(AppConfig.MonitoredApp app) {
        String type = app.getType() != null ? app.getType() : "springboot";
        switch (type) {
            case "redis":
                return checkRedis(app.getHost(), app.getPort()) ? "UP" : "DOWN";
            default:
                return checkSpringBoot(app.getUrl()) ? "UP" : "DOWN";
        }
    }

    private boolean checkSpringBoot(String url) {
        try {
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            return "UP".equalsIgnoreCase((String) response.getBody().get("status"));
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRedis(String host, int port) {
        try (Jedis jedis = new Jedis(host, port)) {
            return "PONG".equalsIgnoreCase(jedis.ping());
        } catch (Exception e) {
            return false;
        }
    }
}
