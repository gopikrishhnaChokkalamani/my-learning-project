package com.example.dashboard.controller;

import com.example.dashboard.config.AppConfig;
import com.example.dashboard.service.HealthCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class DashboardController {

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private HealthCheckService healthCheckService;

    @GetMapping("/")
    public String dashboard(Model model) {
        List<Map<String, Object>> appsWithStatus = appConfig.getMonitored().stream().map(app -> {
            Map<String, Object> entry = new HashMap<>();
            entry.put("name", app.getName());

            if (app.getUrl() != null) {
                entry.put("url", app.getUrl().replace("/actuator/health", ""));
            } else if (app.getHost() != null) {
                entry.put("url", app.getHost() + ":" + app.getPort());
            }

            entry.put("status", healthCheckService.checkStatus(app));
            return entry;
        }).toList();
        model.addAttribute("apps", appsWithStatus);
        return "dashboard";
    }
}
